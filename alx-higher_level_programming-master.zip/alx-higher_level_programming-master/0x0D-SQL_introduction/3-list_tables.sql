-- Lists all tables of a database on my MySQL server.
SHOW TABLES;
