#!/usr/bin/python3
def copy_list(a):
    return a.copy()
