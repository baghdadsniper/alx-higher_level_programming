#!/usr/bin/node
myVar = 333;
