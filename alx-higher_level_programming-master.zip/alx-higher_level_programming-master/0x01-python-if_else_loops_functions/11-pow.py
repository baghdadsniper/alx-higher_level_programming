#!/usr/bin/python3
# Author -Godswill Kalu

def pow(a, b):
    return (a ** b)
